    class Person {

    String name; 
    int age;

    public void run() {
        System.out.println("My name is " + name + ". I can run");
    }

    public void say() {
        System.out.println("My name is " + name + ". I am "+ age+" yers old." );
    }
 }




